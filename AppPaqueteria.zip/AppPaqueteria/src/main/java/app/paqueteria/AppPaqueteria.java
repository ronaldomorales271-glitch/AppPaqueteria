

package app.paqueteria;

import umg.UI.frmMenuPPL;


public class AppPaqueteria {
    
    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> new frmMenuPPL().setVisible(true));;
    }
}
